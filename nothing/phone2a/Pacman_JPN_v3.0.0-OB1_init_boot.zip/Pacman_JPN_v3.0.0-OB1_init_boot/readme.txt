■これは何?
Bootloader UnlockされたNothing Phone(2a)をroot(Magisk導入状態)またはunroot(Magisk非導入状態)にする物です。Fastboot ROMに関してはGitHub側で公開されている物と共通しており、そのまま使っても支障がないのでinit_bootに絞っています。

■使用方法
Fastbootの画面上でInstall_Magisk.batを実行でMagiskがパッチされたinit_bootが焼かれます。戻す場合は、Install_Stock.batで通常に戻すことができます。

■裏話
某所でbootに焼いてしまって文鎮化させてしまったという声があったので被害者を減らすためにバッチを付けています。これを使えば安全性は高まるだろうと思います。
MTKはQualcommと比べてクセが強いイメージだなと思えました。(文鎮化のリスクやドライバーの挙動などなど...今後はQualcommが無難だな...